package Order;

public class Order {
    private final String name;
    private final int qty;
    private final Food food;

    public Order(Food food, int qty) {
        this.name = food.getName();
        this.food = food;
        this.qty = qty;
    }

    public String getName() {
        return name;
    }

    public int getQty() {
        return qty;
    }

    public Food getFood() {
        return food;
    }
}
