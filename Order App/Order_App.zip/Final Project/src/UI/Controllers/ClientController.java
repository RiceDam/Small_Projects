package UI.Controllers;

import Database.DatabaseHandler;
import Network.OrderClient;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class ClientController implements Initializable {
    public static ClientController controller;
    public ScrollPane scroll;
    public AnchorPane anchor;
    public static int pos = 0;
    Button bump;
    ArrayList<HBox> hBoxes = new ArrayList<>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //Initializes the client window
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        controller = this;
        try {
            OrderClient orderClient = new OrderClient(controller);
            orderClient.client.start();
            orderClient.client.connect(5000, orderClient.ip, orderClient.udpPort, orderClient.tcpPort);
            orderClient.client.addListener(new OrderClient(controller));
            System.out.println("Connected! The client program is now waiting for a packet \n");
        }
        catch (Exception e) {
            System.out.println("Unable to connect to server");
        }
    }

    public void addOrder(String message) {
        //Adds order to the client window as a text area
        bump = new Button();
        bump.setText("Bump Order");
        bump.setMinWidth(250);
        bump.setPrefWidth(250);
        bump.setLayoutY(306);
        TextArea newArea = new TextArea();
        newArea.setMinHeight(333);
        newArea.setPrefHeight(333);
        newArea.setMinWidth(250);
        newArea.setPrefWidth(250);
        newArea.setEditable(false);
        newArea.setText(message);
        Pane pane = new Pane(newArea, bump);
        final HBox hBox = new HBox(pane);
        hBox.setMinHeight(333);
        hBox.setPrefHeight(333);
        hBox.setMinWidth(250);
        hBox.setPrefWidth(250);
        hBox.setLayoutX(pos);
        pos += 260;
        hBoxes.add(hBox);
        anchor.getChildren().add(hBox);
        //Sets button to remove box when pressed
        bump.setOnAction(event -> {
            anchor.getChildren().remove(0);
            hBoxes.remove(0);
            for (HBox h : hBoxes) {
                h.setLayoutX(h.getLayoutX() - 260);
            }
            pos -= 260;
        });
    }
}
