package UI.Controllers;

import Database.DatabaseHandler;
import Network.PacketMessage;
import Order.Food;
import Order.Order;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class SendOrder implements Initializable {
    public TableView menuSelection;
    public TableColumn selectName;
    public TableView orderTable;
    public TableColumn orderName;
    public TableColumn orderQty;
    public TextField getQuantity;
    public Label nameDisplay;
    public ObservableList<Food> menu = FXCollections.observableArrayList();
    public ObservableList<Order> order = FXCollections.observableArrayList();
    public TextField getID;
    public Label priceDisplay;


    public void select(MouseEvent mouseEvent) {
        try {
            int index = menuSelection.getSelectionModel().getSelectedIndex();
            nameDisplay.setText(menu.get(index).getName());
        }
        catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("Please select an item in the table");
        }
    }

    public void addToOrder(ActionEvent actionEvent) {
        int price = 0;
        int index = menuSelection.getSelectionModel().getSelectedIndex();
        try {
            if (nameDisplay.getText().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Please choose a menu item");
                alert.setHeaderText(null);
                alert.showAndWait();
                return;
            }
            Integer.parseInt(getQuantity.getText());
        }
        catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a number for Quantity");
            alert.setHeaderText(null);
            alert.showAndWait();
            return;
        }
        order.add(new Order(menu.get(index), Integer.parseInt(getQuantity.getText())));
        for(Order o: order) {
            price += o.getFood().getPrice() * o.getQty();
        }
        orderTable.getItems().setAll(order);
        priceDisplay.setText("$" + price);
        nameDisplay.setText("");
        getQuantity.clear();
    }

    public void removeFromOrder(ActionEvent actionEvent) {
        int price = 0;
        int index = orderTable.getSelectionModel().getSelectedIndex();
        order.remove(index);
        for(Order o: order) {
            price += o.getFood().getPrice() * o.getQty();
        }
        priceDisplay.setText("$" + price);
        orderTable.getItems().setAll(order);
    }

    public void send(ActionEvent actionEvent) {
        Boolean id = getID.getText().isEmpty() || getID.getText().length() > 2;
        Boolean tableEmpty = orderTable.getItems().isEmpty();
        if(!id && !tableEmpty) {
            ObservableList<Order> orders = orderTable.getItems();
            PacketMessage packetMessage = new PacketMessage();
            packetMessage.message = "\nID: " + getID.getText();
            for (Order o : orders) {
                packetMessage.message = packetMessage.message.concat("\n\n" + o.getQty() + " " + o.getName());
            }
            try {
                ServerController.orderServer.c.sendTCP(packetMessage);
                order.clear();
                orderTable.getItems().clear();
                priceDisplay.setText("");
                getID.clear();
            }
            catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Cannot connect to client");
                alert.setHeaderText(null);
                alert.showAndWait();
            }
        }
        if(id){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a 2 character value for the ID");
            alert.setHeaderText(null);
            alert.showAndWait();
        }
        if(tableEmpty) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter items to send");
            alert.setHeaderText(null);
            alert.showAndWait();
        }
    }

    private void loadData() throws SQLException {
        DatabaseHandler handler = DatabaseHandler.getInstance();
        String qu = "SELECT * FROM MENU";
        ResultSet rs = handler.execQuery(qu);
        while (rs.next()) {
            String name = rs.getString("name");
            String price = rs.getString("price");
            menu.add(new Food(name, Double.parseDouble(price)));
        }
        menuSelection.getItems().setAll(menu);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initialCol();
        try {
            loadData();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void initialCol() {
        selectName.setCellValueFactory(new PropertyValueFactory<>("Name"));
        orderName.setCellValueFactory(new PropertyValueFactory<>("Name"));
        orderQty.setCellValueFactory(new PropertyValueFactory<>("Qty"));
    }
}
