package UI.Controllers;

import Network.OrderServer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class ServerController implements Initializable {
    public static ObservableList<String> messages = FXCollections.observableArrayList();
    public Button serverButton;
    public static OrderServer orderServer;
    public Button menuButton;
    public Button sendButton;



    void loadWindow(String location, String title) {
        //Method to load other windows
        try{
            Parent parent = FXMLLoader.load(getClass().getResource(location));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setupServer(ActionEvent actionEvent) {
        //sets up server
        try {
            orderServer = new OrderServer();
            orderServer.server.bind(orderServer.udpPort, orderServer.tcpPort);
            orderServer.server.start();
            orderServer.server.addListener(new OrderServer());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Server is operational");
            alert.setHeaderText(null);
            alert.showAndWait();
            serverButton.setVisible(false);
            menuButton.setVisible(true);
            sendButton.setVisible(true);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void menuWindow(ActionEvent actionEvent) {
        //loads menu window
        loadWindow("../Layouts/menuWindow.fxml", "Menu");
    }

    public void sendWindow(ActionEvent actionEvent) {
        //Loads send order window
        loadWindow("../Layouts/sendOrderWindow.fxml", "Send Order");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //initializes window
        menuButton.setVisible(false);
        sendButton.setVisible(false);
    }
}
