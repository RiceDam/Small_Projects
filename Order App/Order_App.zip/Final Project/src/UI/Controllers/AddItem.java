package UI.Controllers;

import Database.DatabaseHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class AddItem implements Initializable {
    public TextField getName;
    public TextField getPrice;
    public DatabaseHandler handler;
    public Button returnButton;

    void loadWindow(String location, String title) {
        try{
            Parent parent = FXMLLoader.load(getClass().getResource(location));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addItem(ActionEvent actionEvent) {
        String n = getName.getText();
        String p = getPrice.getText();
        try {
            Double.parseDouble(p);
        }
        catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a number for the price");
            alert.setHeaderText(null);
            alert.showAndWait();
            return;
        }
        boolean flag = n.isEmpty() || p.isEmpty();
        if(flag) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter all fields");
            alert.setHeaderText(null);
            alert.showAndWait();
            return;
        }
        String st = "INSERT INTO MENU VALUES (" +
                "'" + n + "'," +
                "'" + p + "'" + ")";
        System.out.println(st);
        if(handler.execAction(st)) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Saved");
            alert.setHeaderText(null);
            alert.showAndWait();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Error with inputting data");
            alert.setHeaderText(null);
            alert.showAndWait();
            return;
        }
        getName.clear();
        getPrice.clear();
    }

    public void returnToMenu(ActionEvent actionEvent) {
        loadWindow("../Layouts/menuWindow.fxml", "Menu");
        Stage stage = (Stage) returnButton.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            handler = DatabaseHandler.getInstance();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
