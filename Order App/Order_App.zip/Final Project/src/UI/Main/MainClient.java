package UI.Main;

import UI.Controllers.ClientController;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class MainClient extends Application {
    Stage stage;

    @Override
    public void start(final Stage primaryStage) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(MainClient.class.getResource("../Layouts/clientWindow.fxml"));
        Parent root = loader.load();
        stage = primaryStage;
        stage.setTitle("Client");
        stage.setScene(new Scene(root, 600, 400));
        stage.show();
        Platform.setImplicitExit(true);
        stage.setOnCloseRequest(event -> {
            Platform.exit();
            System.out.println("Program Closing");
            primaryStage.close();
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
