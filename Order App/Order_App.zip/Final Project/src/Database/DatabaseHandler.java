package Database;

import javax.swing.*;
import java.sql.*;

public class DatabaseHandler {
    private static DatabaseHandler handler = null;
    private static final String DB_url = "jdbc:derby:database/forum;create=true";
    public static Connection conn = null;
    private static Statement stat = null;


    public DatabaseHandler() {
        createConnection();
        createMenuTable();
        createOrderTable();
    }

    private void createConnection() {
        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
            conn = DriverManager.getConnection(DB_url);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        try {
            conn.close();
            System.out.println("Connection closed");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void closeStatement() {
        try {
            stat.close();
            System.out.println("Statement closed");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static DatabaseHandler getInstance() throws SQLException {
        //Creates instance of Database handler
        if(handler == null) {
            handler = new DatabaseHandler();
        }
        return handler;
    }


    private void createMenuTable() {
        String TABLE_NAME = "MENU";
        try {
            stat = conn.createStatement();
            DatabaseMetaData dmn = conn.getMetaData();
            ResultSet tables = dmn.getTables(null,null,TABLE_NAME,null);
            if(tables.next()) {
                System.out.println("Table " + TABLE_NAME + " already exists");
            }
            else {
                String statement = "CREATE TABLE " + TABLE_NAME + "("
                        + "name varchar(200) primary key, \n"
                        + "price varchar(200))";
                System.out.println(statement);
                stat.execute(statement);
            }
        }
        catch (SQLException e) {
            System.out.println(e.getMessage() + " setting up database");
        }
    }

    private void createOrderTable() {
        String TABLE_NAME = "ORDERS";
        try {
            stat = conn.createStatement();
            DatabaseMetaData dmn = conn.getMetaData();
            ResultSet tables = dmn.getTables(null,null,TABLE_NAME,null);
            if(tables.next()) {
                System.out.println("Table " + TABLE_NAME + " already exists");
            }
            else {
                String statement = "CREATE TABLE " + TABLE_NAME + "("
                        + "request varchar(3000) primary key)";
                System.out.println(statement);
                stat.execute(statement);
            }
        }
        catch (SQLException e) {
            System.out.println(e.getMessage() + " setting up database");
        }
    }

    public ResultSet execQuery(String query) {
        //Executes the query which returns a result set
        ResultSet resultSet;
        try{
            stat = conn.createStatement();
            resultSet = stat.executeQuery(query);
        }
        catch (SQLException e) {
            System.out.println("Exception at Execute query");
            return null;
        }
        return resultSet;
    }

    public boolean execAction(String qu) {
        //Executes action that returns a boolean
        try {
            stat = conn.createStatement();
            stat.execute(qu);
            return true;
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            System.out.println("Exception at execQuery" + e.getLocalizedMessage());
            return false;
        }
    }

    public void deleteTable(String s) {
        //Deletes a table depending on the string inserted
        String drop = "DROP TABLE " + s.toUpperCase();
        execAction(drop);
        System.out.println("Table deleted");
    }
}
