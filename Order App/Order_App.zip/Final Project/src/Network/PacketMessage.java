package Network;

public class PacketMessage {
    public String message;
}
